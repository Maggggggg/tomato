# Installation Tomato Mutations Admin

1. Dans Supabase > Authentication, crée ton compte admin (email + mot de passe).
2. Exécute `supabase_admin.sql` dans SQL Editor.
3. Dans la dernière ligne/commentaire du SQL, récupère l'UUID de ton compte dans Authentication > Users et exécute :
   insert into public.admin_users(user_id) values ('UUID') on conflict do nothing;
4. Dans `admin.html`, remplace :
   TON_SUPABASE_URL
   TON_SUPABASE_ANON_KEY
   par les mêmes valeurs publiques que ton jeu.
5. Héberge `admin.html` au même endroit que `index.html`.
6. Ajoute `index_admin_snippet.html` dans ton jeu et appelle `ensureTomatoAuth()` après la création du client Supabase.

IMPORTANT :
- Ne mets JAMAIS la `service_role key` dans admin.html ou index.html.
- L'anon/publishable key peut être dans le navigateur ; la sécurité vient des RLS.
- Le système suppose que chaque joueur possède un compte Supabase Auth.
- Si ton index actuel utilise uniquement localStorage sans Auth, il faut migrer les joueurs vers Auth pour que les bans/permissions soient réellement fiables.
